[PLEASE NOTE] This is not a virus. It's a jar file, which can be unsafe from an unknown source, but it's not from
an unknown source, and you can look at its code yourself at: https://github.com/KyroVibe/SisiMachineEm

[KNOWN BUGS] There is a scatter bug where everything scatters from being visible or not. To fix this hover over
the CPU window until you find a button that says 'ClearCpu'. Click it.

 --- Please Report any bugs you discover to: hunter.barclay18@gmail.com